package com.cts.coursemodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
