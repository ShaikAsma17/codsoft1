package com.cts.coursemodule.enums;



public enum Category {
    
	TECHNOLOGY,
    BUSINESS,
    ARTS,
    SCIENCE,
    HEALTH,
    LANGUAGE,
   
}