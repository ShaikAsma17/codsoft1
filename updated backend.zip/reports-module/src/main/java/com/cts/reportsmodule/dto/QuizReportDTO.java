package com.cts.reportsmodule.dto;

public class QuizReportDTO {
	
	private int quizNumber;
    private Double marks;
   // private String status;
	public int getQuizNumber() {
		return quizNumber;
	}
	public void setQuizNumber(int quizNumber) {
		this.quizNumber = quizNumber;
	}
	public Double getMarks() {
		return marks;
	}
	public void setMarks(Double marks) {
		this.marks = marks;
	}
//	public String getStatus() {
//		return status;
//	}
//	public void setStatus(String status) {
//		this.status = status;
//	}
    
    

}
