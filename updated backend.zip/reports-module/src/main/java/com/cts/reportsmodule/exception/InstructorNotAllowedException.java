package com.cts.reportsmodule.exception;

public class InstructorNotAllowedException extends RuntimeException {
	
	public InstructorNotAllowedException(String message) {
		super(message);
	}

}
