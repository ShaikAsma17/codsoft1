package com.cts.quizmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
