package com.cts.quizmodule.exceptions;

public class InstructorNotAllowedException extends RuntimeException {
	
	public InstructorNotAllowedException(String message) {
		super(message);
	}

}
