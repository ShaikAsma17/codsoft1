package com.cts.quizmodule.exceptions;

public class DuplicateQuizException extends RuntimeException{
	public DuplicateQuizException(String message)
	{
		super(message);
	}
	
	public DuplicateQuizException()
	{
		
	}

}
