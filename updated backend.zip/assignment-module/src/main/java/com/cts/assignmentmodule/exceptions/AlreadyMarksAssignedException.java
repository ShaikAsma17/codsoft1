package com.cts.assignmentmodule.exceptions;

public class AlreadyMarksAssignedException extends RuntimeException {
      public AlreadyMarksAssignedException(String message) {
    	  super(message);
      }
}
