package com.cts.assignmentmodule.exceptions;

public class DuplicateAssignmentSubmissionException  extends RuntimeException{
	public DuplicateAssignmentSubmissionException(String message)
	{
		super(message);
	}
      
}
