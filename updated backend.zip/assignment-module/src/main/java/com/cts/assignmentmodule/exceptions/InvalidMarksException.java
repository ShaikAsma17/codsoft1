package com.cts.assignmentmodule.exceptions;

public class InvalidMarksException extends RuntimeException {

	
	    public InvalidMarksException(String message) {
	    	super(message);
	    }
}
