// src/components/ProfileDetails.js
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt, faSave } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios'; // Import axios
import InstructorDB from '../pages/Dashboard/InstructorDB'; // Import InstructorDB component
function ProfileDetails({ user, onLogout, onUpdateUser }) { // Added onUpdateUser prop
  const [isUpdateMode, setIsUpdateMode] = useState(false);
  const [updatedUserName, setUpdatedUserName] = useState(user.userName);
  const [updatedPassword, setUpdatedPassword] = useState('');
  const Email = localStorage.getItem('email');

  const handleUpdateClick = () => {
    setIsUpdateMode(true);
  };

  const handleSaveClick = async () => {
    try {
      const updateEndpoint = 'http://localhost:8070/api/user/update'; // Your update endpoint
      const response = await axios.put(updateEndpoint, {
        userName: updatedUserName,
        password: updatedPassword,
        email: Email
      });

      if (response.data.success) {
        console.log('User updated successfully!');
        setIsUpdateMode(false);
        // Call the onUpdateUser prop to notify the parent component
        if (onUpdateUser) {
          onUpdateUser({ userName: updatedUserName }); // Pass the updated username
        }
      } else {
        console.error('Error updating user:', response.data.errorMessage);
        // Handle the error
      }
    } catch (error) {
      console.error('Could not update user:', error);
      // Handle the error
    }
  };

  const maskPassword = (password) => {
    return '*'.repeat(password.length);
  };

 

  return (
    <div className="profile-details">
             

      {isUpdateMode ? (
        <div>
          <label>
            Username:
            <input
              type="text"
              value={updatedUserName}
              onChange={(e) => setUpdatedUserName(e.target.value)}
            />
          </label>
          <br />
          <label>
            New Password:
            <input
              type="password"
              value={updatedPassword}
              onChange={(e) => setUpdatedPassword(e.target.value)}
            />
          </label>
          <br />
          <button className="dropdown-item" onClick={handleSaveClick}>
            <FontAwesomeIcon icon={faSave} className="mr-2" /> Save Changes
          </button>
        </div>
      ) : (
        <div>
          <p>Username: {user.userName}</p>
          <p>Email: {user.email}</p>
          <p>Password: {maskPassword(user.password)}</p>
          <button className="dropdown-item" onClick={handleUpdateClick}>
            Update Profile
          </button>
        </div>
      )}
      <button className="dropdown-item logout-button" onClick={onLogout}>
        <FontAwesomeIcon icon={faSignOutAlt} className="mr-2" /> Logout
      </button>
    </div>
  );
}

export default ProfileDetails;