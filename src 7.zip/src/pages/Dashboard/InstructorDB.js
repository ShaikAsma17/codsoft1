// src/pages/InstructorDashboard.js
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import styles from "./InstructorDashboard.module.css"; // Import the CSS module
import { Card, Button, Alert, Spinner, Stack, Badge } from 'react-bootstrap';
import { ClockHistory } from 'react-bootstrap-icons';

// --- Import ALL your images ---
import image1 from "../../assests/Course1.jfif";
import image2 from "../../assests/Course2.jfif";
import image3 from "../../assests/Course3.jfif";
import image4 from "../../assests/Course4.jfif";
import image5 from "../../assests/Course5.jfif";
import image6 from "../../assests/Course6.jfif";
import image7 from "../../assests/Course7.jfif";
import image8 from "../../assests/Course8.jfif";
import image9 from "../../assests/Course9.jfif";
import image10 from "../../assests/Course10.jfif";

// Array of imported images
const courseThumbnails = [ image1, image2, image3, image4, image5, image6, image7, image8, image9, image10 ];

// Helper function to format category names (if you plan to add categories later)
const formatCategory = (category) => {
    if (!category || typeof category !== 'string') return 'N/A';
    return category.charAt(0).toUpperCase() + category.slice(1).toLowerCase();
};

const InstructorDB = () => {
    const [courses, setCourses] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredCourses, setFilteredCourses] = useState([]);
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchInstructorCourses = async () => {
            const email = localStorage.getItem('email');
            const token = localStorage.getItem(`${email}_token`);
            const instructorId = localStorage.getItem(`${email}_uuid`);

            try {
                const response = await axios.get(
                    `http://localhost:8082/api/course/instructorId?instructorId=${instructorId}`,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                );
                setCourses(response.data.data || []);
                setLoading(false);
            } catch (err) {
                console.error('There was an error fetching the courses!', err);
                setError('Failed to load courses created by you.');
                setLoading(false);
            }
        };

        fetchInstructorCourses();
    }, []);

    const handleSearch = (query) => {
        setSearchQuery(query);
    };

    useEffect(() => {
        const filtered = courses.filter(course =>
            course.courseTitle?.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredCourses(filtered);
    }, [searchQuery, courses]);

    if (loading) return (
        <div className={`${styles.containerWithBackground} d-flex justify-content-center align-items-center vh-100`}>
            <Spinner animation="grow" variant="light" />
            <p className="text-light mt-3 lead">Loading your courses...</p>
        </div>
    );
    if (error) return (
        <div className={`${styles.containerWithBackground} d-flex justify-content-center align-items-center vh-100`}>
            <Alert variant="danger" className="text-center">Error: {error}</Alert>
        </div>
    );

    return (
        <div className={styles.containerWithBackground}>
            <Header onSearch={handleSearch} />
            <div className={`${styles.contentOverlay} d-flex flex-column align-items-center`} style={{backgroundColor:'transparent'}}>
                <div className="d-flex justify-content-center mb-4" style={{ width: '100%', maxWidth: '900px' }}>
                    <Button onClick={() => navigate('/createcourse')} className={styles.createCourseButton} >
                        Create New Course
                    </Button>
                </div>
                <div className={`${styles.courseListGrid} course-list-parent`} style={{ width: '100%', maxWidth: '1200px',marginLeft:'50px',marginRight:'50px' }}>
                    {filteredCourses.map((course, index) => (
                        <Card key={course.courseId} className={`${styles.courseCardEnhanced} course-card-item`}>
                            <Card.Img variant="top" alt={course.courseTitle || "Course thumbnail"} src={courseThumbnails[index % courseThumbnails.length]} className={styles.courseCardImage}/>
                            {course.category && <Badge bg="primary" className={styles.categoryBadge}>{formatCategory(course.category)}</Badge>}
                            <Card.Body className="d-flex flex-column align-items-center text-center p-2">
                                <Card.Title className={`${styles.courseCardTitle} mb-1`}>
                                    {course.courseTitle || "Untitled Course"}
                                </Card.Title>
                                {course.duration !== undefined && course.duration !== null && (
                                    <div className="d-flex align-items-center text-muted mb-1" style={{ fontSize: '0.7rem' }}>
                                        <ClockHistory className="me-1" />
                                        <span>{`${course.duration} week${parseInt(course.duration, 10) !== 1 ? 's' : ''}`}</span>
                                    </div>
                                )}
                            </Card.Body>
                            <Card.Footer className={`d-flex justify-content-center ${styles.courseCardFooter}`}>
                                <Button
                                    variant="outline-primary"
                                    size="sm"
                                    className="w-auto"
                                    onClick={() => (window.location.href = `/instructor/course/${course.courseId}`)}
                                >
                                    View Details
                                </Button>
                            </Card.Footer>
                        </Card>
                    ))}
                </div>
                {filteredCourses.length === 0 && !loading && (
                    <Alert variant="info" className="text-center mt-3" style={{ maxWidth: '1200px', width: '100%' }}>
                        {searchQuery ? 'No courses found matching your search.' : "You haven't created any courses yet."}
                    </Alert>
                )}
            </div>
            <Footer />
        </div>
    );
};

export default InstructorDB;