// Register.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Auth.css'; // Import the CSS file

const Register = () => {
  const [userName, setUserName] = useState('');
  const [useremail, setEmail] = useState('');
  const [userpassword, setPassword] = useState('');
  const [userrole, setRole] = useState('STUDENT');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const validateUserName = (name) => {
    if (!name) {
      return 'User name is required.';
    }
    if (name.length < 4) {
      return 'User name must be at least 4 characters long.';
    }
    if (!/[a-zA-Z]/.test(name)) {
      return 'User name must contain at least one alphabet.';
    }
    return '';
  };

  const validateEmail = (email) => {
    if (!email) {
      return 'Email is required.';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return 'Please enter a valid email address.';
    }
    return '';
  };

  const validatePassword = (password) => {
    if (!password) {
      return 'Password is required.';
    }
    if (password.length < 4) {
      return 'Password must be at least 4 characters long.';
    }
    return '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userNameValidation = validateUserName(userName);
    const emailValidation = validateEmail(useremail);
    const passwordValidation = validatePassword(userpassword);

    if (userNameValidation || emailValidation || passwordValidation) {
      setMessage(userNameValidation || emailValidation || passwordValidation);
      return;
    }

    try {
      const response = await axios.post('http://localhost:8070/api/user/register', {
        userName: userName,
        email: useremail,
        password: userpassword,
        role: userrole,
      });

      if (response.data.success) {
        setUserName('');
        setEmail('');
        setPassword('');
        setRole('STUDENT');
        setMessage('Registration successful');
        navigate('/login'); // Redirect to the login page
      } else {
        // Backend should ideally send a more specific error message
        // if username or email already exists.
        setMessage(`Registration failed: ${response.data.errorMessage || 'An error occurred during registration.'}`);
      }
    } catch (error) {
      if (error.response && error.response.data) {
        console.log(error.response.data);
        // Check for specific error messages from the backend
        if (error.response.data.message && error.response.data.message.includes('already exists')) {
           if (error.response.data.message.includes('email')) {
            setMessage('This email address is already registered.');
          } else {
            setMessage(`Registration failed: ${error.response.data.errorMessage || error.response.data.message || 'An unexpected error occurred.'}`);
          }
        } 
      } else if (error.request) {
        setMessage('No response received from the server.');
      }
    }
  };

  return (
    <div className="authPage">
      <form onSubmit={handleSubmit} className="authForm">
        <h2>Register</h2>
        {message && <p className="errorMessage">{message}</p>}
        <div className="formGroup">
          <label>User Name:</label>
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
          />
        </div>
        <div className="formGroup">
          <label>Email:</label>
          <input
            type="email"
            value={useremail}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="formGroup">
          <label>Password:</label>
          <input
            type="password"
            value={userpassword}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="formGroup">
          <label>Role:</label>
          <div className="roleChoice">
            <input
              type="radio"
              id="student"
              value="STUDENT"
              checked={userrole === 'STUDENT'}
              onChange={(e) => setRole(e.target.value)}
            />
            <label htmlFor="student">Student</label>
          </div>
          <div className="roleChoice">
            <input
              type="radio"
              id="instructor"
              value="INSTRUCTOR"
              checked={userrole === 'INSTRUCTOR'}
              onChange={(e) => setRole(e.target.value)}
            />
            <label htmlFor="instructor">Instructor</label>
          </div>
        </div>
        <button type="submit" className="registerButton">Register</button>
      </form>
    </div>
  );
};

export default Register;