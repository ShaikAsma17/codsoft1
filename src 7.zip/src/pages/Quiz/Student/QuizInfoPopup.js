import React from 'react';
import '../css/QuizInfoPopup.css'; // Importing the CSS file

const QuizInfoPopup = ({ quizDetails, totalQuestionsCount, calculateQuizDuration, onStartQuiz }) => {
    return (
        <div className="quiz-info-popup">
            <h2>{quizDetails.title}</h2>
            <p>Number of Questions: {totalQuestionsCount}</p>
            <p>
                <svg xmlns="http://www.w3.org/2000/svg" className="time-icon" viewBox="0 0 16 16">
                    <path d="M8.5 5.6a.5.5 0 1 0-1 0v2.9h-3a.5.5 0 0 0 0 1H8a.5.5 0 0 0 .5-.5z"/>
                    <path d="M6.5 1A.5.5 0 0 1 7 .5h2a.5.5 0 0 1 0 1v.57c1.36.196 2.594.78 3.584 1.64l.012-.013.354-.354-.354-.353a.5.5 0 0 1 .707-.708l1.414 1.415a.5.5 0 1 1-.707.707l-.353-.354-.354.354-.013.012A7 7 0 1 1 7 2.071V1.5a.5.5 0 0 1-.5-.5M8 3a6 6 0 1 0 .001 12A6 6 0 0 0 8 3"/>
                </svg>
                Time Allotted: {calculateQuizDuration() / 60} minutes
            </p>
            <button onClick={onStartQuiz}>Start Quiz</button>
        </div>
    );
};

export default QuizInfoPopup;
