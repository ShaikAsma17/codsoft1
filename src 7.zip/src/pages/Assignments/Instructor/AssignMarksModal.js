// AssignMarksModal.js
import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import styles from '../css/ModalStyles.module.css'; // Use shared modal styles

const AssignMarksModal = ({
    isOpen,
    onRequestClose,
    selectedSubmission,
    selectedAssignment,
    token,
    instructorUuid,
    studentUsernames,
    onMarksAssigned,
}) => {
    const [obtainedMarks, setObtainedMarks] = useState('');
    const [feedback, setFeedback] = useState('');
    const [marksError, setMarksError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const studentUsername = selectedSubmission ? studentUsernames[selectedSubmission.studentId] : null;
    const studentIdDisplay = selectedSubmission ? `ID: ${selectedSubmission.studentId}` : '';
    const totalMarks = selectedAssignment ? selectedAssignment.totalMarks : 0;

    // Reset state and prefill if editing marks (though current logic fetches unreviewed)
     useEffect(() => {
        if (isOpen && selectedSubmission) {
             // Set initial values (might be empty if it's the first time marking)
            setObtainedMarks(selectedSubmission.obtainedMarks?.toString() ?? ''); // Use existing marks if any
            setFeedback(selectedSubmission.feedback || '');
            setMarksError(''); // Clear previous errors
             setIsLoading(false);
        }
         // Clear state when modal closes
         if (!isOpen) {
            setObtainedMarks('');
            setFeedback('');
            setMarksError('');
            setIsLoading(false);
        }
    }, [isOpen, selectedSubmission]);

    const handleObtainedMarksChange = (e) => {
        const value = e.target.value;
        setObtainedMarks(value);
        validateMarks(value); // Validate on change
    };

     const validateMarks = (value) => {
        if (selectedAssignment && value !== '') {
            const obtained = parseFloat(value);
            const total = parseFloat(selectedAssignment.totalMarks);
            if (isNaN(obtained) || obtained < 0) {
                setMarksError('Obtained marks must be a non-negative number.');
                return false;
            } else if (obtained > total) {
                setMarksError(`Marks cannot exceed total (${total}).`);
                 return false;
            } else {
                setMarksError(''); // Clear error if valid
                return true;
            }
        } else if (value === '') {
             setMarksError(''); // Allow empty input initially, but require for submission
             return false; // Not valid for submission if empty
         }
         return true; // Return true if no assignment context (shouldn't happen)
    };

    const handleAssignMarks = async () => {
        if (!selectedAssignment || !selectedSubmission || !instructorUuid) {
            console.error("Cannot assign marks: Missing critical data.", {selectedAssignment, selectedSubmission, instructorUuid});
            setMarksError("An error occurred. Please close the modal and try again.");
            return;
        }

        // Final validation before submitting
         if (obtainedMarks === '') {
             setMarksError('Obtained marks are required.');
             return;
         }
         if (!validateMarks(obtainedMarks)) {
            // If validation function set an error, just return
             return;
         }
        // If validateMarks cleared the error but didn't return false (e.g., complex case), double-check
        if (marksError) {
             return;
         }

        setIsLoading(true); // Start loading

        try {
            const obtained = parseFloat(obtainedMarks);
             // API call using fetch (or axios if preferred)
            const response = await fetch('http://localhost:8083/api/asubmission/assignMarks', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    studentId: selectedSubmission.studentId,
                    instructorId: instructorUuid, // Make sure backend expects this
                    assignmentId: selectedAssignment.assignmentId,
                    obtainedMarks: obtained,
                    feedback: feedback.trim() || null // Send null if feedback is empty/whitespace
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                console.log('Marks assigned successfully', data);
                onMarksAssigned(selectedAssignment.assignmentId); // Notify parent
                 // Optionally close modal here or let parent handle it
                 onRequestClose();
            } else {
                console.error('Error assigning marks (API Response):', data);
                setMarksError(data.message || `Failed to assign marks (${response.status}).`);
            }
        } catch (error) {
            console.error('Error assigning marks (Network/Fetch):', error);
            setMarksError('Network error or failed to parse response. Please try again.');
        } finally {
            setIsLoading(false); // Stop loading
        }
    };

    return (
        <Modal
            isOpen={isOpen}
            onRequestClose={onRequestClose}
            contentLabel="Assign Marks"
             className={styles.modalContent} // Use shared CSS Module class
             overlayClassName={styles.modalOverlay} // Use shared CSS Module class
        >
             <h3 className={styles.modalHeader}>
                Assign Marks for: {studentUsername || studentIdDisplay}
             </h3>

            {selectedSubmission && selectedAssignment ? (
                <div className={styles.form}>
                     <label htmlFor="obtainedMarks" className={styles.label}>
                        Obtained Marks (Max: {totalMarks})
                    </label>
                    <input
                        id="obtainedMarks"
                         type="number"
                         placeholder={`Enter marks (0 - ${totalMarks})`}
                         value={obtainedMarks}
                         onChange={handleObtainedMarksChange}
                         className={`${styles.input} ${marksError ? styles.inputError : ''}`} // Add error class if needed
                         max={totalMarks} // HTML5 validation
                        min="0" // HTML5 validation
                        step="any" // Allow decimals if needed
                        required // HTML5 validation
                        disabled={isLoading}
                    />
                    {marksError && <p className={styles.errorMessage}>{marksError}</p>}

                    <label htmlFor="feedback" className={styles.label}>Feedback (Optional)</label>
                    <textarea
                        id="feedback"
                        placeholder="Provide constructive feedback to the student..."
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        className={styles.textarea}
                        rows={4}
                        disabled={isLoading}
                    />

                    <div className={styles.modalActions}>
                         <button
                             onClick={onRequestClose}
                             className={`${styles.button} ${styles.buttonCancel}`}
                             disabled={isLoading}
                         >
                             Cancel
                        </button>
                        <button
                            onClick={handleAssignMarks}
                             // Disable if loading, error exists, or marks field is empty
                             disabled={isLoading || !!marksError || obtainedMarks === ''}
                            className={`${styles.button} ${styles.buttonPrimary}`}
                        >
                            {isLoading ? 'Submitting...' : 'Submit Marks'}
                        </button>
                    </div>
                </div>
            ) : (
                // Show loading or error state if data isn't ready
                 <p>Loading submission details...</p>
            )}
        </Modal>
    );
};

export default AssignMarksModal;